<?php
/**
 * @copyright 2019 Zyxware
 */
namespace Zyxware\Worldpay\Helper;

use Magento\Store\Model\Store;

/**
 * MinSaleQty value manipulation helper
 */
class Merchantprofile
{
    /**
     * Core store config
     *
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var \Magento\Framework\Math\Random
     */
    protected $mathRandom;

    /**
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Framework\Math\Random $mathRandom
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Serialize\Serializer\Json $serialize,
        \Magento\Framework\Math\Random $mathRandom
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->serialize = $serialize;
        $this->mathRandom = $mathRandom;

    }

   
    /**
     * Check whether value is in form retrieved by _encodeArrayFieldValue()
     *
     * @param string|array $value
     * @return bool
     */
    protected function isEncodedArrayFieldValue($value)
    {
        if (!is_array($value)) {
            return false;
        }
        unset($value['__empty']);
        foreach ($value as $row) {
            if (!is_array($row)
                || !array_key_exists('worldpay_payment_method', $row)
                || !array_key_exists('merchant_code', $row)
            ) {
                return false;
            }
        }
        return true;
    }

    /**
     * Encode value to be used in \Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray
     *
     * @param array $value
     * @return array
     */
    protected function encodeArrayFieldValue(array $value)
    {
        $result = [];
        foreach ($value as $payment_type => $merchant_detail) {
            $resultId = $this->mathRandom->getUniqueHash('_');
            $result[$resultId] = ['worldpay_payment_method' => $payment_type,
                                  'merchant_code' => $merchant_detail['merchant_code'],
                                  'merchant_username' => $merchant_detail['merchant_username'],
                                  'merchant_password' => $merchant_detail['merchant_password'],
                                 ];
        }
        return $result;
    }

    /**
     * Decode value from used in \Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray
     *
     * @param array $value
     * @return array
     */
    protected function decodeArrayFieldValue(array $value)
    {
        $result = array();
        unset($value['__empty']);
        foreach ($value as $row) {
            if (!is_array($row)
                || !array_key_exists('worldpay_payment_method', $row)
                || !array_key_exists('merchant_code', $row)
                || !array_key_exists('merchant_username', $row)
                || !array_key_exists('merchant_password', $row)
            ) {
                continue;
            }
            if (!empty($row['worldpay_payment_method'])
               && !empty($row['merchant_code'])
               && !empty($row['merchant_username'])
               || !empty($row['merchant_password'])
           ) {
                $payment_type = $row['worldpay_payment_method'];
                $rs['merchant_code'] = $row['merchant_code'];
                $rs['merchant_username'] = $row['merchant_username'];
                $rs['merchant_password'] = $row['merchant_password'];
                $result[$payment_type] = $rs;
            }
        }
        return $result;
    }



    /**
     * Make value readable by \Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray
     *
     * @param string|array $value
     * @return array
     */
    public function makeArrayFieldValue($value)
    {
        $value = $this->serialize->unserialize($value);
        if (!$this->isEncodedArrayFieldValue($value)) {
            $value = $this->encodeArrayFieldValue($value);
        }
        return $value;
    }

    /**
     * Make value ready for store
     *
     * @param string|array $value
     * @return string
     */
    public function makeStorableArrayFieldValue($value)
    {

        if ($this->isEncodedArrayFieldValue($value)) {
            $value = $this->decodeArrayFieldValue($value);
        }
        $value = $this->serialize->serialize($value);

        return $value;
    }

    /**
     * Retrieve merchant detail value from config
     *
     * @param int $customerGroupId
     * @param null|string|bool|int|Store $store
     * @return float|null
     */
    public function getConfigValue($paymenttype, $store = null)
    {
        $value = $this->scopeConfig->getValue(
            'worldpay/merchant_config/merchant_profile',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $store
        );
        $value = $this->serialize->unserialize($value);
        if ($this->isEncodedArrayFieldValue($value)) {
            $value = $this->decodeArrayFieldValue($value);
        }

        if (!empty($value[$paymenttype]))
            return $value[$paymenttype];

        return;
    }

}
