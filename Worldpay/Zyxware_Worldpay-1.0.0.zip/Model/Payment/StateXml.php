<?php
/**
 * @copyright 2019 Zyxware
 */
namespace Zyxware\Worldpay\Model\Payment;

/**
 * Reading xml
 */
class StateXml implements \Zyxware\Worldpay\Model\Payment\State
{
    private $_xml;
    /**
     * Constructor
     * @param $xml
     */
    public function __construct($xml)
    {
        $this->_xml = $xml;
    }

    /**
     * Retrive ordercode from xml
     * @return string 
     */
    public function getOrderCode()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode['orderCode'];
    }

    /**
     * Retrive ordercode from xml
     * @return string 
     */
    public function getPaymentStatus()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->lastEvent;
    }

    /**
     * Retrive status node from xml
     * @return xml 
     */
    private function _getStatusNode()
    {
        if (isset($this->_xml->reply)) {
            return $this->_xml->reply->orderStatus;
        }

        return $this->_xml->notify->orderStatusEvent;
    }

    /**
     * Retrive amount from xml
     * @return string 
     */
    public function getAmount()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->amount['value'];
    }

    /**
     * Retrive merchant code from xml
     * @return string 
     */
    public function getMerchantCode()
    {
        return (string) $this->_xml['merchantCode'];
    }

    /**
     * Retrive Risk Score from xml
     * @return string 
     */
    public function getRiskScore()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->riskScore['value'];
    }

    /**
     * Retrive payment method from xml
     * @return string 
     */
    public function getPaymentMethod()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->paymentMethod;
    }

    /**
     * Retrive card number from xml
     * @return string 
     */
    public function getCardNumber()
    {
        /** @var SimpleXMLElement $statusNode */
        $statusNode = $this->_getStatusNode();
        if (isset($statusNode->payment->cardNumber)) {
            return (string) $statusNode->payment->cardNumber;
        }

        return (string) $statusNode->payment->paymentMethodDetail->card['number'];
    }

    /**
     * Retrive avs result code from xml
     * @return string 
     */
    public function getAvsResultCode()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->AVSResultCode['description'];
    }

    /**
     * Retrive cvc result code from xml
     * @return string 
     */
    public function getCvcResultCode()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->CVCResultCode['description'];
    }

    /**
     * Retrive advance risk provider from xml
     * @return string 
     */
    public function getAdvancedRiskProvider()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->riskScore['Provider'];
    }

    /**
     * Retrive advance risk provider id from xml
     * @return string 
     */
    public function getAdvancedRiskProviderId()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->riskScore['RGID'];
    }

    /**
     * Retrive advance risk provider Threshold from xml
     * @return string 
     */
    public function getAdvancedRiskProviderThreshold()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->riskScore['tRisk'];
    }

    /**
     * Retrive advance risk provider Score from xml
     * @return string 
     */
    public function getAdvancedRiskProviderScore()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->riskScore['tScore'];
    }

    /**
     * Retrive advance risk provider final score from xml
     * @return string 
     */
    public function getAdvancedRiskProviderFinalScore()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->riskScore['finalScore'];
    }

    /**
     * Retrive Payment refusal code from xml
     * @return string 
     */
    public function getPaymentRefusalCode()
    {
        $statusNode = $this->_getStatusNode();
        return $statusNode->payment->issueResponseCode['code'] ? : $statusNode->payment->ISO8583ReturnCode['code'];
    }

    /**
     * Retrive Payment refusal Description from xml
     * @return string 
     */
    public function getPaymentRefusalDescription()
    {
        $statusNode = $this->_getStatusNode();
        return $statusNode->payment->issueResponseCode['description'] ? : $statusNode->payment->ISO8583ReturnCode['description'];
    }

    /**
     * Retrive journal reference from xml
     * @return string 
     */
    public function getJournalReference($state)
    {
        $statusNode = $this->_getStatusNode();
        $journalNodes = $statusNode->journal;

        foreach ($journalNodes as $journal) {
            if ($journal['journalType'] == $state) {
                $reference = $journal->journalReference['reference'];
                if ($reference) {
                    return $reference->__toString();
                }
            }
        }

        return false;
    }

    /**
     * Retrive full Refund from xml
     * @return string 
     */
    public function getFullRefundAmount()
    {
        $statusNode = $this->_getStatusNode();

        foreach ($statusNode->journal as $journal) {
            if ($journal['journalType'] == \Zyxware\Worldpay\Model\Payment\State::STATUS_SENT_FOR_REFUND) {
                foreach($journal->accountTx as $account) {
                    if ($account['accountType'] == "IN_PROCESS_CAPTURED") {
                        $amount = $account->amount['value'];
                        if ($amount) {
                            return $amount->__toString();
                        }
                    }
                }
            }
        }

        return false;
    }

    /**
     * Retrive Asynchronus Notification from xml
     * @return string 
     */
    public function isAsyncNotification()
    {
        return isset($this->_xml->notify);
    }

    /**
     * Tells if this response is a direct reply xml sent from WP server     
     * @return bool
     */
    public function isDirectReply()
    {
        return ! $this->isAsyncNotification();
    }

    /**
     * Retrive AAV Addewss Result Code from xml
     * @return string 
     */
    public function getAAVAddressResultCode()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->AAVAddressResultCode['description'];
    }

    /**
     * Retrive AAV Postcode Result Code from xml
     * @return string 
     */
    public function getAAVPostcodeResultCode()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->AAVPostcodeResultCode['description'];
    }

    /**
     * Retrive AAV card holder Name Result Code from xml
     * @return string 
     */
    public function getAAVCardholderNameResultCode()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->AAVCardholderNameResultCode['description'];
    }

    /**
     * Retrive AAV Telephone Result Code from xml
     * @return string 
     */
    public function getAAVTelephoneResultCode()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->AAVTelephoneResultCode['description'];
    }

    /**
     * Retrive AAV Email Result Code from xml
     * @return string 
     */
    public function getAAVEmailResultCode()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->AAVEmailResultCode['description'];
    }

    /*
    *Retrieve currency code from xml
    */
    public function getCurrency()
    {
        $statusNode = $this->_getStatusNode();
        return (string) $statusNode->payment->amount['currencyCode'];   
    }

}
