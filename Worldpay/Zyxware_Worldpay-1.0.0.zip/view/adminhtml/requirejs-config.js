var config = {
    map: {
        '*': {
            worldpay: 'https://cdn.worldpay.com/v1/worldpay.js',
            worldpayForm: 'Zyxware_Worldpay/js/wp-form',
        }
    }
};
