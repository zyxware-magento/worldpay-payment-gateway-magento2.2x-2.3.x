var config = {
    map: {
        '*': {
            worldpay: 'https://payments.worldpay.com/resources/cse/js/worldpay-cse-1.0.1.min.js',
        }
    }
};
